package com.example.noblee.NonActivityClasses;

public class TODO {

    /*
    TODO :
        Donaton activity 0%
        Se rensigner (pour group a faire) 0%
        question au medecin 0%
        search option 0%
        coriger les ereur orthographe 0%
        les interfaces 60%
        notifaction lorsque vendeur accept commande 0%
        location,image... pour cote vendeur 0%
        photo profile pour user 0%
        cote medecin (ZAKI) ?%
        update pub/commantaire dans publication (aouter au firebase mais pas la liste des pub/commantaires





     */
}
