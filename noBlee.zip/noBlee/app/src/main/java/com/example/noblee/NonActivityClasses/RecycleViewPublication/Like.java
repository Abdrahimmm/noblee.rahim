package com.example.noblee.NonActivityClasses.RecycleViewPublication;

public class Like {

    String user;
    public Like(String uid) {
        user = uid;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
